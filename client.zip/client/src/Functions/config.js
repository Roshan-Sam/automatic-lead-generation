const config = {
    baseApiUrl: "http://127.0.0.1:8000/api/",
    baseApiImageUrl: "http://127.0.0.1:8000",
};

export default config;
