import CompanyNav from "../../../components/company/company-nav/CompanyNav";

const CompanyDashboard = () => {
  return (
    <div>
      <CompanyNav />
    </div>
  );
};

export default CompanyDashboard;
